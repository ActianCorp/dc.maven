package com.pervasive.di;

public interface ConnectionUser
{    
    boolean supportsLocal();
    
    boolean useConnection(ConnectionBuilder cxnBuilder);
}
